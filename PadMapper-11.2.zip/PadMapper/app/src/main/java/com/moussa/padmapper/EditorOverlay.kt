package com.moussa.padmapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

class EditorOverlay(
    ctx: Context,
    private val svc: PadService,
    private val list: MutableList<Binding>
) : FrameLayout(ctx) {

    private var selected: Binding? = null
    private var dragB: Binding? = null
    private var dragEnd = false
    private val canvasView = PadCanvas(ctx)
    private val bottom = LinearLayout(ctx)
    private val selLabel = TextView(ctx)
    private val typeButtons = ArrayList<Button>()
    private val styleButtons = ArrayList<Button>()
    private val bottomBox = LinearLayout(ctx)
    private val durRow = LinearLayout(ctx)
    private val durLabel = TextView(ctx)
    private val seek = SeekBar(ctx)
    private var picker: View? = null

    init {
        val pad = (10 * resources.displayMetrics.density).toInt()
        setBackgroundColor(0x66000000)
        addView(
            canvasView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        // Barre du haut
        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.VERTICAL
        top.setBackgroundColor(0xCC000000.toInt())
        top.setPadding(pad, pad / 2, pad, pad / 2)
        val row1 = LinearLayout(ctx)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.gravity = Gravity.CENTER_VERTICAL
        val info = TextView(ctx)
        info.text = "Touche ＋ Stick / ＋ Croix pour les faire apparaître, ou appuie sur un bouton de la manette. " +
                "Glisse chaque rond sur la commande du jeu. Stick : le rond jaune règle la taille."
        info.setTextColor(Color.WHITE)
        info.textSize = 12f
        row1.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val done = Button(ctx)
        done.text = "Terminé"
        done.setOnClickListener { svc.closeEditor(true, list) }
        row1.addView(done)
        val row2 = LinearLayout(ctx)
        row2.orientation = LinearLayout.HORIZONTAL
        fun addBtn(label: String, row: LinearLayout = row2, action: () -> Unit) {
            val btn = Button(ctx)
            btn.text = label
            btn.isAllCaps = false
            btn.textSize = 12f
            btn.minWidth = 0
            btn.minimumWidth = 0
            btn.setOnClickListener { action() }
            row.addView(btn)
        }
        addBtn("＋ Stick G") { onPadKey("stickL", "Stick G") }
        addBtn("＋ Stick D") { onPadKey("stickR", "Stick D") }
        addBtn("＋ Croix") { addCross() }
        val row3 = LinearLayout(ctx)
        row3.orientation = LinearLayout.HORIZONTAL
        addBtn("💾 Enregistrer", row3) { saveProfile(false) }
        addBtn("💾＋ Nouveau", row3) { saveProfile(true) }
        addBtn("📂 Charger", row3) { showProfilePicker() }
        top.addView(row1)
        top.addView(row2)
        top.addView(row3)
        addView(
            top,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        )

        // Barre du bas (bouton sélectionné)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.setBackgroundColor(0xCC000000.toInt())
        bottom.setPadding(pad, pad / 2, pad, pad / 2)
        selLabel.setTextColor(Color.WHITE)
        selLabel.textSize = 13f
        bottom.addView(selLabel)
        val editable = listOf(ActionType.TAP, ActionType.HOLD, ActionType.SWIPE, ActionType.TURBO)
        for (t in editable) {
            val b = Button(ctx)
            b.text = t.label
            b.isAllCaps = false
            b.textSize = 12f
            b.minWidth = 0
            b.minimumWidth = 0
            b.setOnClickListener { applyType(t) }
            typeButtons.add(b)
            bottom.addView(b)
        }
        for (rep in listOf(false, true)) {
            val sb = Button(ctx)
            sb.text = if (rep) "Repeat" else "Hold"
            sb.isAllCaps = false
            sb.textSize = 12f
            sb.minWidth = 0
            sb.minimumWidth = 0
            sb.visibility = View.GONE
            sb.setOnClickListener { setStyle(rep) }
            styleButtons.add(sb)
            bottom.addView(sb)
        }
        val del = Button(ctx)
        del.text = "Suppr."
        del.isAllCaps = false
        del.textSize = 12f
        del.minWidth = 0
        del.minimumWidth = 0
        del.setOnClickListener { deleteSelected() }
        bottom.addView(del)

        // Réglage de durée : barre + boutons − / ＋ (appui pour Tap fixe, glissé pour Swipe)
        durRow.orientation = LinearLayout.VERTICAL
        durRow.setBackgroundColor(0xCC000000.toInt())
        durRow.setPadding(pad, pad / 2, pad, 0)
        durLabel.setTextColor(Color.WHITE)
        durLabel.textSize = 13f
        durRow.addView(durLabel)
        val durCtl = LinearLayout(ctx)
        durCtl.orientation = LinearLayout.HORIZONTAL
        durCtl.gravity = Gravity.CENTER_VERTICAL
        durCtl.addView(makeStepButton(ctx, "−", -1))
        durCtl.addView(seek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        durCtl.addView(makeStepButton(ctx, "＋", 1))
        durRow.addView(durCtl)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val sel = selected ?: return
                if (sel.type != ActionType.TAP && sel.type != ActionType.SWIPE) return
                setDur(sel, progress)
                durLabel.text = durText(sel)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        durRow.visibility = View.GONE
        bottomBox.orientation = LinearLayout.VERTICAL
        bottomBox.visibility = View.GONE
        bottomBox.addView(durRow)
        bottomBox.addView(bottom)
        bottom.visibility = View.VISIBLE
        addView(
            bottomBox,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        )
    }

    private fun fmtMs(ms: Int): String = if (ms >= 1000) "${ms / 1000.0} s" else "$ms ms"

    private fun curDur(s: Binding): Int =
        if (s.type == ActionType.TAP) (if (s.pressMs > 0) s.pressMs else 70) else s.swipeMs

    private fun durMin(s: Binding): Int = if (s.type == ActionType.TAP) 1 else 20

    private fun durMax(s: Binding): Int = if (s.type == ActionType.TAP) 1000 else 2000

    private fun setDur(s: Binding, v: Int) {
        val x = v.coerceIn(durMin(s), durMax(s))
        if (s.type == ActionType.TAP) s.pressMs = x else s.swipeMs = x
    }

    private fun durText(s: Binding): String = when (s.type) {
        ActionType.TAP -> "Durée d'appui : " + fmtMs(curDur(s))
        ActionType.SWIPE -> "Durée du glissé : " + fmtMs(curDur(s))
        else -> ""
    }

    private fun adjustDuration(delta: Int) {
        val s = selected ?: return
        if (s.type != ActionType.TAP && s.type != ActionType.SWIPE) return
        setDur(s, curDur(s) + delta)
        refreshPanel()
    }

    /** Bouton − ou ＋ : un appui change de 1 ms, en le maintenant ça va plus vite. */
    private fun makeStepButton(ctx: Context, txt: String, dir: Int): Button {
        val btn = Button(ctx)
        btn.text = txt
        btn.minWidth = 0
        btn.minimumWidth = 0
        val rep = object : Runnable {
            override fun run() {
                adjustDuration(dir * 5)
                btn.postDelayed(this, 60)
            }
        }
        btn.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    adjustDuration(dir)
                    v.postDelayed(rep, 450)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.removeCallbacks(rep)
            }
            true
        }
        return btn
    }

    // ---------- Profils enregistrés ----------

    private fun saveProfile(asNew: Boolean) {
        val base = svc.currentLabel()
        val names = Store.namedList(context)
        var name = base
        if (asNew) {
            var n = 2
            while (names.contains(name)) {
                name = "$base ($n)"
                n++
            }
        }
        Store.saveNamed(context, name, list)
        Toast.makeText(context, "Profil « $name » enregistré", Toast.LENGTH_SHORT).show()
    }

    private fun closePicker() {
        picker?.let { removeView(it) }
        picker = null
    }

    private fun showProfilePicker() {
        closePicker()
        val pad = (12 * resources.displayMetrics.density).toInt()
        val names = Store.namedList(context)
        val box = LinearLayout(context)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(0xEE202020.toInt())
        box.setPadding(pad, pad, pad, pad)
        val title = TextView(context)
        title.text = if (names.isEmpty()) "Aucun profil enregistré" else "Charger un profil"
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        box.addView(title)
        val sv = ScrollView(context)
        val listBox = LinearLayout(context)
        listBox.orientation = LinearLayout.VERTICAL
        for (n in names) {
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            val load = Button(context)
            load.text = n
            load.isAllCaps = false
            load.setOnClickListener {
                loadProfile(n)
                closePicker()
            }
            row.addView(load, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val del = Button(context)
            del.text = "✕"
            var armed = false
            del.setOnClickListener {
                if (!armed) {
                    armed = true
                    del.text = "Sûr ?"
                } else {
                    Store.deleteNamed(context, n)
                    showProfilePicker()
                }
            }
            row.addView(del)
            listBox.addView(row)
        }
        sv.addView(listBox)
        box.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val close = Button(context)
        close.text = "Fermer"
        close.setOnClickListener { closePicker() }
        box.addView(close)
        val h = (resources.displayMetrics.heightPixels * 0.6f).toInt()
        addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h, Gravity.CENTER))
        picker = box
    }

    private fun loadProfile(name: String) {
        val loaded = Store.loadNamed(context, name)
        list.clear()
        list.addAll(loaded)
        selected = null
        refreshPanel()
        canvasView.invalidate()
        Toast.makeText(context, "Profil « $name » chargé : touche Terminé pour l'appliquer", Toast.LENGTH_LONG).show()
    }

    /** Appelé par le service quand un bouton / stick / croix est actionné pendant l'édition. */
    fun onPadKey(id: String, name: String) {
        val b = list.firstOrNull { it.key == id } ?: makeBinding(id, name).also { list.add(it) }
        selected = b
        refreshPanel()
        canvasView.invalidate()
    }

    private fun addCross() {
        val dirs = listOf(
            Triple("a_up", "Croix ↑", Pair(0.15f, 0.50f)),
            Triple("a_down", "Croix ↓", Pair(0.15f, 0.72f)),
            Triple("a_left", "Croix ←", Pair(0.08f, 0.61f)),
            Triple("a_right", "Croix →", Pair(0.22f, 0.61f))
        )
        for ((id, name, pos) in dirs) {
            if (list.none { it.key == id }) {
                list.add(Binding(id, name, x = pos.first, y = pos.second))
            }
        }
        selected = list.firstOrNull { it.key == "a_up" }
        refreshPanel()
        canvasView.invalidate()
    }

    private fun makeBinding(id: String, name: String): Binding {
        if (id == "stickL" || id == "stickR") {
            val cx = if (id == "stickL") 0.18f else 0.82f
            return Binding(id, name, ActionType.STICK, cx, 0.65f, cx + 0.08f, 0.65f, Store.stickStyle(context) == 1)
        }
        val n = list.size
        return Binding(
            id, name,
            x = 0.15f + 0.07f * (n % 10),
            y = 0.25f + 0.12f * ((n / 10) % 5)
        )
    }

    private fun refreshPanel() {
        val s = selected
        bottomBox.visibility = if (s == null) View.GONE else View.VISIBLE
        if (s != null) {
            durRow.visibility = if (s.type == ActionType.TAP || s.type == ActionType.SWIPE) View.VISIBLE else View.GONE
            durLabel.text = durText(s)
            if (s.type == ActionType.TAP || s.type == ActionType.SWIPE) {
                seek.max = durMax(s)
                seek.progress = curDur(s)
            }
            val isStick = s.type == ActionType.STICK
            selLabel.text = if (isStick) {
                s.name + " · " + (if (s.repeat) "Repeat" else "Hold") + "  "
            } else {
                s.name + "  "
            }
            typeButtons.forEach { it.visibility = if (isStick) View.GONE else View.VISIBLE }
            styleButtons.forEach { it.visibility = if (isStick) View.VISIBLE else View.GONE }
        }
    }

    private fun setStyle(rep: Boolean) {
        val s = selected ?: return
        if (s.type != ActionType.STICK) return
        s.repeat = rep
        refreshPanel()
    }

    private fun applyType(t: ActionType) {
        val s = selected ?: return
        if (s.type == ActionType.STICK) return
        s.type = t
        if (t == ActionType.SWIPE) {
            s.x2 = (s.x + 0.15f).coerceAtMost(0.98f)
            s.y2 = s.y
        }
        refreshPanel()
        canvasView.invalidate()
    }

    private fun deleteSelected() {
        val s = selected ?: return
        list.remove(s)
        selected = null
        refreshPanel()
        canvasView.invalidate()
    }

    private inner class PadCanvas(ctx: Context) : View(ctx) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.YELLOW
            strokeWidth = 6f
            style = Paint.Style.STROKE
        }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        private val r: Float get() = 28f * resources.displayMetrics.density

        override fun onDraw(c: Canvas) {
            txt.textSize = 11f * resources.displayMetrics.density
            for (b in list) {
                val cx = b.x * width
                val cy = b.y * height
                if (b.type == ActionType.STICK) {
                    val ex = b.x2 * width
                    val ey = b.y2 * height
                    val rad = hypot(ex - cx, ey - cy)
                    c.drawCircle(cx, cy, rad, line)
                    fill.color = 0xCCFFC107.toInt()
                    c.drawCircle(ex, ey, r * 0.5f, fill)
                    fill.color = if (b === selected) 0xCC4CAF50.toInt() else 0xCC9C27B0.toInt()
                    c.drawCircle(cx, cy, r * 0.9f, fill)
                    c.drawText(b.name, cx, cy + txt.textSize / 3, txt)
                    continue
                }
                if (b.type == ActionType.SWIPE) {
                    val ex = b.x2 * width
                    val ey = b.y2 * height
                    c.drawLine(cx, cy, ex, ey, line)
                    fill.color = 0xCCFF9800.toInt()
                    c.drawCircle(ex, ey, r * 0.7f, fill)
                    c.drawText("fin", ex, ey + txt.textSize / 3, txt)
                }
                fill.color = if (b === selected) 0xCC4CAF50.toInt() else 0xCC2196F3.toInt()
                c.drawCircle(cx, cy, r, fill)
                c.drawText(b.name.take(7), cx, cy + txt.textSize / 3, txt)
                c.drawText(b.type.label, cx, cy + r + txt.textSize, txt)
            }
        }

        private fun hit(x: Float, y: Float) {
            dragB = null
            val rr = r * 1.4f
            for (b in list.asReversed()) {
                val hasEnd = b.type == ActionType.SWIPE || b.type == ActionType.STICK
                if (hasEnd && hypot(x - b.x2 * width, y - b.y2 * height) < rr) {
                    dragB = b
                    dragEnd = true
                    return
                }
                if (hypot(x - b.x * width, y - b.y * height) < rr) {
                    dragB = b
                    dragEnd = false
                    return
                }
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    hit(event.x, event.y)
                    selected = dragB
                    refreshPanel()
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    val b = dragB
                    if (b != null) {
                        val fx = (event.x / width).coerceIn(0f, 1f)
                        val fy = (event.y / height).coerceIn(0f, 1f)
                        if (dragEnd) {
                            b.x2 = fx
                            b.y2 = fy
                        } else {
                            if (b.type == ActionType.STICK) {
                                b.x2 = (b.x2 + (fx - b.x)).coerceIn(0f, 1f)
                                b.y2 = (b.y2 + (fy - b.y)).coerceIn(0f, 1f)
                            }
                            b.x = fx
                            b.y = fy
                        }
                        invalidate()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragB = null
            }
            return true
        }
    }
}
