package com.moussa.padmapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

class PadService : AccessibilityService() {

    companion object {
        var instance: PadService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var engine: TouchEngine
    private var sw = 0
    private var sh = 0
    private var currentPkg = "global"
    private var ownForeground = false
    private var bindings: MutableList<Binding> = mutableListOf()
    private var bubble: TextView? = null
    private var editor: EditorOverlay? = null
    private var stickView: StickView? = null
    private val turbo = HashMap<String, Runnable>()
    private val axisDown = HashMap<String, Boolean>()
    private val stickOn = HashMap<String, Boolean>()
    private val stickEdit = HashMap<String, Boolean>()
    private val btnDown = HashMap<String, Boolean>()

    var mappingOn = true
        set(v) {
            field = v
            bubble?.text = if (v) "🎮" else "⏸"
            if (::engine.isInitialized) {
                if (!v) releaseAll()
                updateStickOverlay()
            }
        }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        refreshMetrics()
        engine = TouchEngine(this, { sw }, { sh })
        // Diagnostic affiché dans la bulle : 🎮 annulés/refusés
        engine.onStats = { c, f ->
            bubble?.textSize = 11f
            bubble?.text = "🎮$c/$f"
        }
        if (Keys.calib == null) Keys.calib = Store.loadCalib(this)
        bindings = Store.load(this, currentPkg)
        showBubble()
        updateStickOverlay()
        // Diagnostic : nombre maximum de doigts virtuels acceptés par ce téléphone
        Toast.makeText(
            this,
            "PadMapper — doigts max : " + GestureDescription.getMaxStrokeCount(),
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::wm.isInitialized) refreshMetrics()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = event.packageName?.toString() ?: return
        if (p == packageName) {
            val cn = event.className?.toString() ?: ""
            if (cn.startsWith("com.moussa.padmapper") && cn.endsWith("Activity")) {
                ownForeground = true
                releaseAll()
                updateStickOverlay()
            }
            return
        }
        if (p == "com.android.systemui") return
        refreshMetrics()
        ownForeground = false
        if (p != currentPkg) {
            currentPkg = p
            releaseAll()
            bindings = Store.load(this, p)
        }
        updateStickOverlay()
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null || !Keys.isPad(event)) return false
        val id = Keys.id(event)
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount > 0) {
            return editor != null ||
                    (mappingOn && !ownForeground &&
                            bindings.any { it.key == id && it.type != ActionType.STICK })
        }
        return handleButton(id, Keys.name(event), event.action == KeyEvent.ACTION_DOWN)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        releaseAll()
        editor?.let { wm.removeView(it) }
        bubble?.let { wm.removeView(it) }
        stickView?.let { wm.removeView(it) }
        editor = null
        bubble = null
        stickView = null
        instance = null
        return super.onUnbind(intent)
    }

    // ---------- Boutons ----------

    private fun handleButton(id: String, name: String, down: Boolean): Boolean {
        val ed = editor
        if (ed != null) {
            if (down) ed.onPadKey(id, name)
            return true
        }
        if (!mappingOn || ownForeground) return false
        val b = bindings.firstOrNull { it.key == id && it.type != ActionType.STICK } ?: return false
        val was = btnDown[id] ?: false
        if (was == down) return true
        btnDown[id] = down
        if (down) press(b) else release(b)
        return true
    }

    private fun press(b: Binding) {
        when (b.type) {
            ActionType.TAP -> engine.tap(px(b.x), py(b.y), if (b.pressMs > 0) b.pressMs else 70)
            ActionType.HOLD -> engine.down(b.key, px(b.x), py(b.y))
            ActionType.SWIPE -> engine.swipe(px(b.x), py(b.y), px(b.x2), py(b.y2), b.swipeMs)
            ActionType.TURBO -> startTurbo(b)
            ActionType.STICK -> {}
        }
    }

    private fun release(b: Binding) {
        when (b.type) {
            ActionType.HOLD -> engine.up(b.key)
            ActionType.TURBO -> stopTurbo(b.key)
            else -> {}
        }
    }

    private fun startTurbo(b: Binding) {
        stopTurbo(b.key)
        val r = object : Runnable {
            override fun run() {
                engine.tap(px(b.x), py(b.y))
                handler.postDelayed(this, 90)
            }
        }
        turbo[b.key] = r
        handler.post(r)
    }

    private fun stopTurbo(key: String) {
        turbo.remove(key)?.let { handler.removeCallbacks(it) }
    }

    private fun releaseAll() {
        turbo.keys.toList().forEach { stopTurbo(it) }
        if (::engine.isInitialized) engine.upAll()
        stickOn.clear()
        axisDown.clear()
        stickEdit.clear()
        btnDown.clear()
    }

    @Suppress("DEPRECATION")
    private fun metrics(): DisplayMetrics {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return m
    }

    private fun refreshMetrics() {
        val m = metrics()
        sw = m.widthPixels
        sh = m.heightPixels
    }

    private fun px(f: Float): Float = f * sw
    private fun py(f: Float): Float = f * sh

    // ---------- Axes : sticks, croix, gâchettes ----------

    /** Appelé par la mini fenêtre invisible à chaque mouvement de stick. */
    fun onMotion(e: MotionEvent) {
        if (sw == 0) refreshMetrics()
        val c = Keys.calib
        val ls = c?.ls
        val rs = c?.rs
        val lScale = ls?.scale ?: 1f
        val rScale = rs?.scale ?: 1f
        val lx = if (ls != null) e.getAxisValue(ls.ax) else e.getAxisValue(MotionEvent.AXIS_X)
        val ly = if (ls != null) e.getAxisValue(ls.ay) else e.getAxisValue(MotionEvent.AXIS_Y)
        val z = e.getAxisValue(MotionEvent.AXIS_Z)
        val rx0 = e.getAxisValue(MotionEvent.AXIS_RX)
        val rz = e.getAxisValue(MotionEvent.AXIS_RZ)
        val ry0 = e.getAxisValue(MotionEvent.AXIS_RY)
        val rx = if (rs != null) e.getAxisValue(rs.ax) else if (abs(z) >= abs(rx0)) z else rx0
        val ry = if (rs != null) e.getAxisValue(rs.ay) else if (abs(rz) >= abs(ry0)) rz else ry0

        val hx = e.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
        axisButton("a_left", "Croix ←", hx < -0.5f)
        axisButton("a_right", "Croix →", hx > 0.5f)
        axisButton("a_up", "Croix ↑", hy < -0.5f)
        axisButton("a_down", "Croix ↓", hy > 0.5f)

        var ltCal = false
        var rtCal = false
        if (c != null) {
            for (ab in c.axisBtns) {
                if (ab.id == "a_lt") ltCal = true
                if (ab.id == "a_rt") rtCal = true
                axisButton(
                    ab.id, Keys.labels[ab.id] ?: ab.id,
                    (e.getAxisValue(ab.axis) - ab.rest) * ab.sign > 0.5f
                )
            }
        }
        if (!ltCal) {
            val lt = max(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE))
            axisButton("a_lt", "LT", lt > 0.5f)
        }
        if (!rtCal) {
            val rt = max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS))
            axisButton("a_rt", "RT", rt > 0.5f)
        }

        stick("stickL", "Stick G", lx / lScale, ly / lScale)
        stick("stickR", "Stick D", rx / rScale, ry / rScale)
    }

    private fun axisButton(id: String, name: String, down: Boolean) {
        val was = axisDown[id] ?: false
        if (was == down) return
        axisDown[id] = down
        handleButton(id, name, down)
    }

    private fun stick(id: String, name: String, ax: Float, ay: Float) {
        val m = hypot(ax, ay)
        val ed = editor
        if (ed != null) {
            val on = m > 0.6f
            if (on != (stickEdit[id] ?: false)) {
                stickEdit[id] = on
                if (on) ed.onPadKey(id, name)
            }
            return
        }
        if (!mappingOn || ownForeground) return
        val b = bindings.firstOrNull { it.key == id && it.type == ActionType.STICK } ?: return
        val active = stickOn[id] ?: false
        if (m < 0.18f) {
            if (active) {
                stickOn[id] = false
                engine.up(id)
            }
            return
        }
        val k = if (m > 1f) 1f / m else 1f
        val cx = px(b.x)
        val cy = py(b.y)
        val rad = hypot(px(b.x2) - cx, py(b.y2) - cy)
        if (!active) {
            stickOn[id] = true
            // repeat = false : Maintenir (doigt posé en continu) ; true : Répéter (geste refait en boucle)
            engine.down(id, cx, cy, b.repeat)
        }
        engine.moveTo(id, cx + ax * k * rad, cy + ay * k * rad)
    }

    /** Test du doigt virtuel : fait tourner un doigt 3 secondes autour d'un point (coordonnées écran). */
    fun selfTest(cx: Float, cy: Float, radius: Float, repeat: Boolean) {
        if (!::engine.isInitialized) return
        val id = "selftest"
        engine.down(id, cx, cy, repeat)
        var step = 0
        val r = object : Runnable {
            override fun run() {
                step++
                val ang = step * 0.18
                engine.moveTo(id, cx + (cos(ang) * radius).toFloat(), cy + (sin(ang) * radius).toFloat())
                if (step < 100) handler.postDelayed(this, 30) else engine.up(id)
            }
        }
        handler.postDelayed(r, 30)
    }

    /**
     * La fenêtre invisible qui lit les sticks prend le "focus" : on ne la met que
     * si le profil du jeu utilise un stick, la croix ou une gâchette (ou pendant l'édition).
     */
    private fun updateStickOverlay() {
        if (!::wm.isInitialized) return
        val need = Store.axisMode(this) && !ownForeground && mappingOn &&
                (editor != null || bindings.any { it.type == ActionType.STICK || it.key.startsWith("a_") })
        val cur = stickView
        if (need && cur == null) {
            val v = StickView(this, this)
            val lp = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            try {
                wm.addView(v, lp)
                stickView = v
            } catch (e: Exception) {
                stickView = null
            }
        } else if (!need && cur != null) {
            try {
                wm.removeView(cur)
            } catch (e: Exception) {
            }
            stickView = null
            stickOn.clear()
            axisDown.clear()
        }
    }

    // ---------- Bulle et éditeur ----------

    private fun showBubble() {
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)
        val density = resources.displayMetrics.density
        val tv = TextView(ctx)
        tv.text = "🎮"
        tv.textSize = 18f
        tv.gravity = Gravity.CENTER
        tv.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0x99000000.toInt())
        tv.background = bg

        val size = (44 * density).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = (120 * density).toInt()

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        var longDone = false
        val longRun = Runnable {
            longDone = true
            mappingOn = !mappingOn
        }

        tv.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x
                    sy = lp.y
                    tx = e.rawX
                    ty = e.rawY
                    moved = false
                    longDone = false
                    handler.postDelayed(longRun, 700)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) {
                        moved = true
                        handler.removeCallbacks(longRun)
                    }
                    if (moved) {
                        lp.x = sx + dx
                        lp.y = sy + dy
                        wm.updateViewLayout(view, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRun)
                    if (!moved && !longDone) openEditor()
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longRun)
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
    }

    fun openEditor() {
        if (editor != null) return
        releaseAll()
        refreshMetrics()
        val list = Store.load(this, currentPkg)
        val lp = WindowManager.LayoutParams(
            sw, sh,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        val themed = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)
        val ed = EditorOverlay(themed, this, list)
        wm.addView(ed, lp)
        editor = ed
        bubble?.visibility = View.GONE
        updateStickOverlay()
    }

    fun closeEditor(save: Boolean, list: List<Binding>) {
        editor?.let { wm.removeView(it) }
        editor = null
        if (save) {
            Store.save(this, currentPkg, list)
            bindings = list.toMutableList()
        }
        bubble?.visibility = View.VISIBLE
        releaseAll()
        updateStickOverlay()
    }
}
