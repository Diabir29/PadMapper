package com.moussa.padmapper;

interface IInputService {
    // Code réservé par Shizuku : détruit le service
    void destroy() = 16777114;

    // Injecte un événement tactile réel (action : DOWN/UP/MOVE/POINTER_DOWN/POINTER_UP)
    oneway void inject(int action, int actionIndex, long downTime, in int[] ids, in float[] xs, in float[] ys) = 1;
}
