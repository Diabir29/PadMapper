package com.moussa.padmapper

/** Ce que sait faire un "moteur de doigts virtuels" (accessibilité ou Shizuku). */
interface Touch {
    fun down(id: String, x: Float, y: Float, reset: Boolean = false)
    fun moveTo(id: String, x: Float, y: Float)
    fun up(id: String)
    fun upAll()
    fun tap(x: Float, y: Float, holdMs: Int = 40)
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Int = 240)
}
