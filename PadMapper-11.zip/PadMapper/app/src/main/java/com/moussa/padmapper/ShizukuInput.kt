package com.moussa.padmapper

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

/** Connexion à Shizuku et au service qui injecte les touches. */
object ShizukuInput {
    const val PKG = "moe.shizuku.privileged.api"

    @Volatile
    private var svc: IInputService? = null
    private var binding = false
    var lastError = ""

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            svc = if (binder != null && binder.pingBinder()) IInputService.Stub.asInterface(binder) else null
            binding = false
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
            binding = false
        }
    }

    fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0)
        true
    } catch (e: Exception) {
        false
    }

    fun running(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun granted(): Boolean = try {
        running() && !Shizuku.isPreV11() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun requestPermission(code: Int) {
        try {
            Shizuku.requestPermission(code)
        } catch (e: Throwable) {
            lastError = e.toString()
        }
    }

    fun ready(): Boolean = svc != null

    fun connect(ctx: Context) {
        if (svc != null || binding || !granted()) return
        binding = true
        try {
            val args = Shizuku.UserServiceArgs(
                ComponentName(ctx.packageName, InputUserService::class.java.name)
            ).daemon(false).processNameSuffix("input").debuggable(false).version(2)
            Shizuku.bindUserService(args, conn)
        } catch (e: Throwable) {
            binding = false
            lastError = e.toString()
        }
    }

    fun inject(action: Int, index: Int, downTime: Long, ids: IntArray, xs: FloatArray, ys: FloatArray) {
        val s = svc ?: return
        try {
            s.inject(action, index, downTime, ids, xs, ys)
        } catch (e: Throwable) {
            svc = null
        }
    }

    fun status(ctx: Context): String = when {
        ready() -> "✅ Shizuku connecté : vrais appuis tactiles"
        !installed(ctx) -> "❌ Shizuku n'est pas installé"
        !running() -> "⚠️ Shizuku est installé mais pas démarré"
        !granted() -> "⚠️ Shizuku démarré : autorisation de PadMapper à donner"
        else -> "⏳ Connexion à Shizuku…" + (if (lastError.isNotEmpty()) "\n$lastError" else "")
    }
}
