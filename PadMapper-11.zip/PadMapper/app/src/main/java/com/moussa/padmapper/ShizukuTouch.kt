package com.moussa.padmapper

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent

/**
 * Vrais doigts virtuels : chaque doigt reste posé tant qu'on ne le relève pas,
 * exactement comme sur un écran. Plusieurs doigts en même temps, sans coupure.
 */
class ShizukuTouch(
    private val screenW: () -> Int,
    private val screenH: () -> Int
) : Touch {

    private class P(val id: Int, var x: Float, var y: Float)

    private val handler = Handler(Looper.getMainLooper())
    private val ptrs = LinkedHashMap<String, P>()
    private val runs = HashMap<String, Runnable>()
    private var downTime = 0L
    private var moveScheduled = false
    private var counter = 0

    private fun cx(v: Float) = v.coerceIn(0f, (screenW() - 1).toFloat())
    private fun cy(v: Float) = v.coerceIn(0f, (screenH() - 1).toFloat())

    private fun freeId(): Int {
        var i = 0
        while (ptrs.values.any { it.id == i }) i++
        return i
    }

    private fun ordered(): List<P> = ptrs.values.sortedBy { it.id }

    private fun send(action: Int, index: Int) {
        val list = ordered()
        val ids = IntArray(list.size) { list[it].id }
        val xs = FloatArray(list.size) { list[it].x }
        val ys = FloatArray(list.size) { list[it].y }
        ShizukuInput.inject(action, index, downTime, ids, xs, ys)
    }

    override fun down(id: String, x: Float, y: Float, reset: Boolean) {
        if (ptrs.containsKey(id)) return
        val p = P(freeId(), cx(x), cy(y))
        ptrs[id] = p
        if (ptrs.size == 1) {
            downTime = SystemClock.uptimeMillis()
            send(MotionEvent.ACTION_DOWN, 0)
        } else {
            send(MotionEvent.ACTION_POINTER_DOWN, ordered().indexOf(p))
        }
    }

    override fun moveTo(id: String, x: Float, y: Float) {
        val p = ptrs[id] ?: return
        p.x = cx(x)
        p.y = cy(y)
        if (!moveScheduled) {
            moveScheduled = true
            handler.postDelayed({
                moveScheduled = false
                if (ptrs.isNotEmpty()) send(MotionEvent.ACTION_MOVE, 0)
            }, 8)
        }
    }

    override fun up(id: String) {
        val p = ptrs[id] ?: return
        if (ptrs.size == 1) {
            send(MotionEvent.ACTION_UP, 0)
        } else {
            send(MotionEvent.ACTION_POINTER_UP, ordered().indexOf(p))
        }
        ptrs.remove(id)
    }

    override fun upAll() {
        runs.values.forEach { handler.removeCallbacks(it) }
        runs.clear()
        ptrs.keys.toList().forEach { up(it) }
    }

    override fun tap(x: Float, y: Float, holdMs: Int) {
        val id = "t${counter++}"
        down(id, x, y, false)
        val r = Runnable {
            runs.remove(id)
            up(id)
        }
        runs[id] = r
        handler.postDelayed(r, holdMs.coerceAtLeast(30).toLong())
    }

    override fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Int) {
        val id = "s${counter++}"
        down(id, x1, y1, false)
        val steps = (durationMs / 16).coerceIn(1, 120)
        var i = 0
        val r = object : Runnable {
            override fun run() {
                i++
                val t = i.toFloat() / steps
                moveTo(id, x1 + (x2 - x1) * t, y1 + (y2 - y1) * t)
                if (i < steps) {
                    handler.postDelayed(this, 16)
                } else {
                    handler.postDelayed({
                        runs.remove(id)
                        up(id)
                    }, 24)
                }
            }
        }
        runs[id] = r
        handler.postDelayed(r, 16)
    }
}
