package com.moussa.padmapper

import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.lang.reflect.Method
import kotlin.system.exitProcess

/**
 * Ce service est lancé par Shizuku dans un processus avec les droits "shell".
 * Il injecte de vrais événements tactiles, comme un doigt posé sur l'écran.
 */
class InputUserService : IInputService.Stub() {

    private var manager: Any? = null
    private var injectMethod: Method? = null

    init {
        try {
            var inst: Any? = null
            try {
                val g = Class.forName("android.hardware.input.InputManagerGlobal")
                inst = g.getDeclaredMethod("getInstance").invoke(null)
            } catch (e: Throwable) {
            }
            if (inst == null) {
                val c = Class.forName("android.hardware.input.InputManager")
                inst = c.getDeclaredMethod("getInstance").invoke(null)
            }
            manager = inst
            injectMethod = inst!!.javaClass.getMethod(
                "injectInputEvent",
                InputEvent::class.java,
                Int::class.javaPrimitiveType
            )
        } catch (e: Throwable) {
            manager = null
            injectMethod = null
        }
    }

    override fun destroy() {
        exitProcess(0)
    }

    override fun inject(
        action: Int,
        actionIndex: Int,
        downTime: Long,
        ids: IntArray,
        xs: FloatArray,
        ys: FloatArray
    ) {
        val m = injectMethod ?: return
        val n = ids.size
        if (n == 0) return
        val props = Array(n) { i ->
            val p = MotionEvent.PointerProperties()
            p.id = ids[i]
            p.toolType = MotionEvent.TOOL_TYPE_FINGER
            p
        }
        val coords = Array(n) { i ->
            val c = MotionEvent.PointerCoords()
            c.x = xs[i]
            c.y = ys[i]
            c.pressure = 1f
            c.size = 1f
            c
        }
        val act = if (action == MotionEvent.ACTION_POINTER_DOWN || action == MotionEvent.ACTION_POINTER_UP) {
            action or (actionIndex shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        } else {
            action
        }
        val ev = MotionEvent.obtain(
            downTime, SystemClock.uptimeMillis(), act, n, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        try {
            m.invoke(manager, ev, 0)
        } catch (e: Throwable) {
        } finally {
            ev.recycle()
        }
    }
}
