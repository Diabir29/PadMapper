package com.moussa.padmapper

import android.content.Context
import android.os.Build
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController

/**
 * Mini fenêtre invisible (1 pixel) qui reçoit les axes de la manette : sticks, croix, gâchettes.
 * Comme elle prend le focus, elle demande aussi le mode plein écran immersif :
 * sinon Android réaffiche les boutons de navigation (retour, accueil, récents) pendant le jeu.
 */
@Suppress("DEPRECATION")
class StickView(ctx: Context, private val svc: PadService) : View(ctx) {

    init {
        systemUiVisibility = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (Build.VERSION.SDK_INT >= 30) {
            val c = windowInsetsController
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars())
                c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if ((event.source and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK ||
            event.actionMasked != MotionEvent.ACTION_MOVE
        ) {
            return super.onGenericMotionEvent(event)
        }
        svc.onMotion(event)
        return true
    }
}
