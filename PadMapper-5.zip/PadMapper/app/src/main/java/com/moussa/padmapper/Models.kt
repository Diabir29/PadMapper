package com.moussa.padmapper

import android.content.Context
import android.view.InputDevice
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

enum class ActionType(val label: String) {
    TAP("Tap"),
    HOLD("Maintenir"),
    SWIPE("Swipe"),
    TURBO("Turbo"),
    STICK("Stick")
}

data class Binding(
    val key: String,
    var name: String,
    var type: ActionType = ActionType.TAP,
    var x: Float = 0.5f,
    var y: Float = 0.5f,
    var x2: Float = 0.6f,
    var y2: Float = 0.5f,
    var repeat: Boolean = false,
    /** Durée d'appui du TAP en ms (0 = appui rapide par défaut). */
    var pressMs: Int = 0,
    /** Durée du glissé SWIPE en ms. */
    var swipeMs: Int = 240
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("key", key)
        put("name", name)
        put("type", type.name)
        put("x", x.toDouble())
        put("y", y.toDouble())
        put("x2", x2.toDouble())
        put("y2", y2.toDouble())
        put("repeat", repeat)
        put("pressMs", pressMs)
        put("swipeMs", swipeMs)
    }

    companion object {
        fun fromJson(o: JSONObject): Binding = Binding(
            o.getString("key"),
            o.getString("name"),
            ActionType.valueOf(o.getString("type")),
            o.getDouble("x").toFloat(),
            o.getDouble("y").toFloat(),
            o.getDouble("x2").toFloat(),
            o.getDouble("y2").toFloat(),
            o.optBoolean("repeat", false),
            o.optInt("pressMs", 0),
            o.optInt("swipeMs", 240)
        )
    }
}

/** Axes d'un stick analogique trouvés pendant l'étalonnage. */
class StickCal(val ax: Int, val ay: Int, val scale: Float)

/** Une touche (ex. gâchette) qui est en réalité un axe analogique. */
class AxisBtn(val id: String, val axis: Int, val sign: Int, val rest: Float)

/** Résultat de l'étalonnage de la manette. */
class Calib(val ls: StickCal?, val rs: StickCal?, val sources: Map<String, String>) {
    val keyToLogical = HashMap<String, String>()
    val axisBtns = ArrayList<AxisBtn>()

    init {
        for ((id, src) in sources) {
            if (src.startsWith("ax:")) {
                val p = src.split(":")
                axisBtns.add(AxisBtn(id, p[1].toInt(), p[2].toInt(), p[3].toFloat()))
            } else {
                keyToLogical[src] = id
            }
        }
    }

    fun toJson(): String {
        val o = JSONObject()
        if (ls != null) {
            o.put("ls", JSONObject().put("ax", ls.ax).put("ay", ls.ay).put("s", ls.scale.toDouble()))
        }
        if (rs != null) {
            o.put("rs", JSONObject().put("ax", rs.ax).put("ay", rs.ay).put("s", rs.scale.toDouble()))
        }
        val so = JSONObject()
        for ((k, v) in sources) so.put(k, v)
        o.put("src", so)
        return o.toString()
    }

    companion object {
        fun fromJson(s: String): Calib? {
            return try {
                val o = JSONObject(s)
                val lj = o.optJSONObject("ls")
                val rj = o.optJSONObject("rs")
                val ls = if (lj != null) StickCal(lj.getInt("ax"), lj.getInt("ay"), lj.getDouble("s").toFloat()) else null
                val rs = if (rj != null) StickCal(rj.getInt("ax"), rj.getInt("ay"), rj.getDouble("s").toFloat()) else null
                val src = HashMap<String, String>()
                val so = o.getJSONObject("src")
                for (k in so.keys()) src[k] = so.getString(k)
                Calib(ls, rs, src)
            } catch (e: Exception) {
                null
            }
        }
    }
}

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("padmapper", Context.MODE_PRIVATE)

    fun load(c: Context, pkg: String): MutableList<Binding> {
        val s = prefs(c).getString("profile_$pkg", null) ?: return mutableListOf()
        val list = mutableListOf<Binding>()
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) list.add(Binding.fromJson(arr.getJSONObject(i)))
        } catch (e: Exception) {
            list.clear()
        }
        return list
    }

    fun axisMode(c: Context): Boolean = prefs(c).getBoolean("axis_mode", true)

    fun setAxisMode(c: Context, v: Boolean) {
        prefs(c).edit().putBoolean("axis_mode", v).apply()
    }

    /** 0 = Maintenir (Hold), 1 = Répéter (Repeat) */
    fun stickStyle(c: Context): Int = prefs(c).getInt("stick_style", 0)

    fun setStickStyle(c: Context, v: Int) {
        prefs(c).edit().putInt("stick_style", v).apply()
    }

    fun loadCalib(c: Context): Calib? {
        val s = prefs(c).getString("calib", null) ?: return null
        return Calib.fromJson(s)
    }

    fun saveCalib(c: Context, cal: Calib) {
        prefs(c).edit().putString("calib", cal.toJson()).apply()
    }

    fun save(c: Context, pkg: String, list: List<Binding>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(c).edit().putString("profile_$pkg", arr.toString()).apply()
    }
}

object Keys {
    /** Étalonnage en cours d'utilisation (partagé entre l'app et le service). */
    var calib: Calib? = null

    val labels: Map<String, String> = mapOf(
        "stickL" to "Stick G",
        "stickR" to "Stick D",
        "a_lt" to "LT",
        "a_rt" to "RT",
        "c_LB" to "LB",
        "c_RB" to "RB",
        "c_LS" to "LS",
        "c_RS" to "RS",
        "c_SELECT" to "SELECT",
        "c_START" to "START",
        "c_A" to "A",
        "c_B" to "B",
        "c_X" to "X",
        "c_Y" to "Y",
        "a_up" to "Croix ↑",
        "a_down" to "Croix ↓",
        "a_left" to "Croix ←",
        "a_right" to "Croix →"
    )

    fun rawId(e: KeyEvent): String =
        if (e.keyCode == KeyEvent.KEYCODE_UNKNOWN) "s${e.scanCode}" else "k${e.keyCode}"

    fun id(e: KeyEvent): String {
        val raw = rawId(e)
        val mapped = calib?.keyToLogical?.get(raw)
        if (mapped != null) return mapped
        return when (e.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> "a_up"
            KeyEvent.KEYCODE_DPAD_DOWN -> "a_down"
            KeyEvent.KEYCODE_DPAD_LEFT -> "a_left"
            KeyEvent.KEYCODE_DPAD_RIGHT -> "a_right"
            KeyEvent.KEYCODE_BUTTON_L2 -> "a_lt"
            KeyEvent.KEYCODE_BUTTON_R2 -> "a_rt"
            else -> raw
        }
    }

    fun name(e: KeyEvent): String {
        val key = id(e)
        val l = labels[key]
        if (l != null) return l
        return if (e.keyCode == KeyEvent.KEYCODE_UNKNOWN) "SCAN${e.scanCode}"
        else KeyEvent.keyCodeToString(e.keyCode).removePrefix("KEYCODE_")
    }

    fun isPad(e: KeyEvent): Boolean {
        val s = e.source
        return (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
                (s and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD ||
                KeyEvent.isGamepadButton(e.keyCode)
    }
}
