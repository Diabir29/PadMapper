package com.moussa.padmapper

import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot
import kotlin.math.max

/** Étalonnage de la manette, dans le style d'Octopus : sticks, puis touches, puis test final. */
class CalibrationActivity : Activity() {

    private class Step(val id: String, val label: String, val stick: Boolean)

    private val steps = listOf(
        Step("stickL", "stick analogique gauche", true),
        Step("stickR", "stick analogique droit", true),
        Step("a_lt", "LT", false),
        Step("a_rt", "RT", false),
        Step("c_LB", "LB", false),
        Step("c_RB", "RB", false),
        Step("c_LS", "LS", false),
        Step("c_RS", "RS", false),
        Step("c_SELECT", "SELECT", false),
        Step("c_START", "START", false),
        Step("c_A", "A", false),
        Step("c_B", "B", false),
        Step("c_X", "X", false),
        Step("c_Y", "Y", false)
    )

    private val pairs = listOf(
        intArrayOf(MotionEvent.AXIS_X, MotionEvent.AXIS_Y),
        intArrayOf(MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ),
        intArrayOf(MotionEvent.AXIS_RX, MotionEvent.AXIS_RY)
    )

    private val buttonAxes = intArrayOf(
        MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_RTRIGGER,
        MotionEvent.AXIS_BRAKE, MotionEvent.AXIS_GAS,
        MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ,
        MotionEvent.AXIS_RX, MotionEvent.AXIS_RY,
        MotionEvent.AXIS_THROTTLE, MotionEvent.AXIS_RUDDER
    )

    private val allAxes = intArrayOf(MotionEvent.AXIS_X, MotionEvent.AXIS_Y) + buttonAxes

    private val handler = Handler(Looper.getMainLooper())
    private var idx = 0
    private var testing = false
    private var waitingNext = false

    private var lsCal: StickCal? = null
    private var rsCal: StickCal? = null
    private val sources = HashMap<String, String>()
    private val used = HashSet<String>()
    private val usedAxes = HashSet<Int>()

    private val rest = HashMap<Int, Float>()
    private val pressCount = HashMap<String, Int>()
    private val axisDown = HashMap<Int, Int>()
    private val sectors = HashMap<Int, BooleanArray>()
    private val maxMag = HashMap<Int, Float>()

    private lateinit var tabs: List<TextView>
    private lateinit var msg: TextView
    private lateinit var skip: Button
    private lateinit var btnRe: Button
    private lateinit var btnDone: Button
    private lateinit var diagram: PadDiagram

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val d = resources.displayMetrics.density
        val pad = (12 * d).toInt()
        val dark = 0xFF121212.toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)
        root.setBackgroundColor(dark)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "Étalonnage de la manette de jeu"
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val close = Button(this)
        close.text = "✕"
        close.setOnClickListener { finish() }
        header.addView(close)
        root.addView(header)

        val tabRow = LinearLayout(this)
        tabRow.orientation = LinearLayout.HORIZONTAL
        val tabList = ArrayList<TextView>()
        for (t in listOf("Stick analogique", "Touche", "Test final")) {
            val tv = TextView(this)
            tv.text = t
            tv.gravity = Gravity.CENTER
            tv.textSize = 12f
            tv.setPadding(pad / 2, pad / 3, pad / 2, pad / 3)
            tv.setTextColor(Color.WHITE)
            tabRow.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            tabList.add(tv)
        }
        tabs = tabList
        root.addView(tabRow)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.gravity = Gravity.CENTER_VERTICAL
        left.setPadding(pad, pad, pad, pad)
        msg = TextView(this)
        msg.setTextColor(Color.WHITE)
        msg.textSize = 15f
        left.addView(msg)
        skip = Button(this)
        skip.text = "PASSER >>"
        skip.setOnClickListener { skipStep() }
        left.addView(skip)
        btnRe = Button(this)
        btnRe.text = "Rétalonner"
        btnRe.setOnClickListener { startCalibration() }
        left.addView(btnRe)
        btnDone = Button(this)
        btnDone.text = "Terminé"
        btnDone.setOnClickListener { finish() }
        left.addView(btnDone)

        diagram = PadDiagram(this)
        body.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        body.addView(diagram, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.2f))
        root.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        startCalibration()
    }

    // ---------- Déroulement ----------

    private fun setTab(i: Int) {
        tabs.forEachIndexed { k, t ->
            t.setBackgroundColor(if (k == i) 0xFF2BFFAA.toInt() else 0x00000000)
            t.setTextColor(if (k == i) Color.BLACK else Color.WHITE)
        }
    }

    private fun clearProbe() {
        pressCount.clear()
        sectors.clear()
        maxMag.clear()
    }

    private fun startCalibration() {
        handler.removeCallbacksAndMessages(null)
        idx = 0
        testing = false
        waitingNext = false
        lsCal = null
        rsCal = null
        sources.clear()
        used.clear()
        usedAxes.clear()
        axisDown.clear()
        clearProbe()
        diagram.pressed.clear()
        diagram.lDot = null
        diagram.rDot = null
        btnRe.visibility = View.GONE
        btnDone.visibility = View.GONE
        skip.visibility = View.VISIBLE
        showStep()
    }

    private fun showStep() {
        val st = steps[idx]
        setTab(if (st.stick) 0 else 1)
        diagram.highlight = st.id
        diagram.invalidate()
        msg.text = if (st.stick) {
            "Veuillez faire pivoter le ${st.label} à plusieurs reprises."
        } else {
            "Veuillez appuyer sur ${st.label} à plusieurs reprises."
        }
    }

    private fun stepDone(text: String) {
        msg.text = "✓ $text"
        waitingNext = true
        diagram.invalidate()
        handler.postDelayed({ goNext() }, 900)
    }

    private fun goNext() {
        handler.removeCallbacksAndMessages(null)
        idx++
        waitingNext = false
        clearProbe()
        if (idx >= steps.size) startTest() else showStep()
    }

    private fun skipStep() {
        if (testing || waitingNext) return
        goNext()
    }

    private fun startTest() {
        val cal = Calib(lsCal, rsCal, HashMap(sources))
        Keys.calib = cal
        Store.saveCalib(this, cal)
        testing = true
        setTab(2)
        diagram.highlight = null
        diagram.pressed.clear()
        diagram.lDot = null
        diagram.rDot = null
        msg.text = "Appuyez sur les touches et déplacez les sticks analogiques pour tester.\n" +
                "Si un problème survient, veuillez rétalonner."
        skip.visibility = View.GONE
        btnRe.visibility = View.VISIBLE
        btnDone.visibility = View.VISIBLE
        diagram.invalidate()
    }

    // ---------- Touches ----------

    private fun register(key: String, full: String) {
        if (waitingNext || testing) return
        if (used.contains(key)) return
        val n = (pressCount[key] ?: 0) + 1
        pressCount[key] = n
        if (n >= 3) {
            val st = steps[idx]
            sources[st.id] = full
            used.add(key)
            stepDone("${st.label} étalonné, veuillez arrêter d'appuyer")
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!Keys.isPad(event)) return super.dispatchKeyEvent(event)
        if (testing) {
            val id = Keys.id(event)
            if (event.action == KeyEvent.ACTION_DOWN) {
                diagram.pressed.add(id)
            } else if (event.action == KeyEvent.ACTION_UP) {
                diagram.pressed.remove(id)
            }
            diagram.invalidate()
            return true
        }
        if (!waitingNext && event.action == KeyEvent.ACTION_DOWN &&
            event.repeatCount == 0 && !steps[idx].stick
        ) {
            val raw = Keys.rawId(event)
            register(raw, raw)
        }
        return true
    }

    // ---------- Axes ----------

    private fun noteRest(e: MotionEvent) {
        for (a in allAxes) {
            if (!rest.containsKey(a)) rest[a] = e.getAxisValue(a)
        }
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if ((event.source and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK ||
            event.actionMasked != MotionEvent.ACTION_MOVE
        ) {
            return super.onGenericMotionEvent(event)
        }
        noteRest(event)
        if (testing) {
            updateTest(event)
            return true
        }
        if (waitingNext) return true
        val st = steps[idx]
        if (st.stick) stickProbe(event, st) else axisProbe(event)
        return true
    }

    private fun stickProbe(e: MotionEvent, st: Step) {
        for ((pi, p) in pairs.withIndex()) {
            if (usedAxes.contains(p[0])) continue
            val x = e.getAxisValue(p[0])
            val y = e.getAxisValue(p[1])
            val m = hypot(x, y)
            if (m > 0.6f) {
                val ang = Math.atan2(y.toDouble(), x.toDouble()) + Math.PI
                val sec = (ang / (2 * Math.PI) * 8).toInt().coerceIn(0, 7)
                val cov = sectors.getOrPut(pi) { BooleanArray(8) }
                cov[sec] = true
                maxMag[pi] = max(maxMag[pi] ?: 0f, m)
                if (cov.count { it } >= 7) {
                    val cal = StickCal(p[0], p[1], (maxMag[pi] ?: 1f).coerceIn(0.6f, 1.5f))
                    if (st.id == "stickL") lsCal = cal else rsCal = cal
                    usedAxes.add(p[0])
                    usedAxes.add(p[1])
                    stepDone("Stick étalonné, vous pouvez arrêter le mouvement")
                    return
                }
            }
        }
    }

    private fun axisProbe(e: MotionEvent) {
        for (a in buttonAxes) {
            if (usedAxes.contains(a)) continue
            val rv = rest[a] ?: continue
            val d = e.getAxisValue(a) - rv
            val sign = if (d > 0.6f) 1 else if (d < -0.6f) -1 else 0
            val prev = axisDown[a] ?: 0
            axisDown[a] = sign
            if (sign != 0 && prev != sign) register("ax:$a:$sign", "ax:$a:$sign:$rv")
        }
    }

    // ---------- Test final ----------

    private fun setPressed(id: String, on: Boolean) {
        if (on) diagram.pressed.add(id) else diagram.pressed.remove(id)
    }

    private fun updateTest(e: MotionEvent) {
        val c = Keys.calib
        val ls = c?.ls
        val rs = c?.rs
        val lx = if (ls != null) e.getAxisValue(ls.ax) / ls.scale else e.getAxisValue(MotionEvent.AXIS_X)
        val ly = if (ls != null) e.getAxisValue(ls.ay) / ls.scale else e.getAxisValue(MotionEvent.AXIS_Y)
        val rx = if (rs != null) e.getAxisValue(rs.ax) / rs.scale else e.getAxisValue(MotionEvent.AXIS_Z)
        val ry = if (rs != null) e.getAxisValue(rs.ay) / rs.scale else e.getAxisValue(MotionEvent.AXIS_RZ)
        diagram.lDot = Pair(lx.coerceIn(-1f, 1f), ly.coerceIn(-1f, 1f))
        diagram.rDot = Pair(rx.coerceIn(-1f, 1f), ry.coerceIn(-1f, 1f))
        if (c != null) {
            for (ab in c.axisBtns) {
                setPressed(ab.id, (e.getAxisValue(ab.axis) - ab.rest) * ab.sign > 0.5f)
            }
        }
        val hx = e.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
        setPressed("a_left", hx < -0.5f)
        setPressed("a_right", hx > 0.5f)
        setPressed("a_up", hy < -0.5f)
        setPressed("a_down", hy > 0.5f)
        diagram.invalidate()
    }
}
