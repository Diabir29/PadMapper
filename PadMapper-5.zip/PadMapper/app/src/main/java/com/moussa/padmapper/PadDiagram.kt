package com.moussa.padmapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Dessin d'une manette, avec la commande en cours d'étalonnage en vert. */
class PadDiagram(ctx: Context) : View(ctx) {

    var highlight: String? = null
    val pressed = HashSet<String>()
    var lDot: Pair<Float, Float>? = null
    var rDot: Pair<Float, Float>? = null

    private val dim = 0xFFFFB347.toInt()
    private val green = 0xFF2BFFAA.toInt()
    private val body = 0xFF6B5A33.toInt()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    // cercles : id -> (x, y, rayon) dans un repère de 1,4 x 1
    private val circles = mapOf(
        "stickL" to floatArrayOf(0.38f, 0.42f, 0.11f),
        "stickR" to floatArrayOf(0.88f, 0.68f, 0.11f),
        "c_SELECT" to floatArrayOf(0.62f, 0.42f, 0.03f),
        "c_START" to floatArrayOf(0.78f, 0.42f, 0.03f),
        "c_Y" to floatArrayOf(1.04f, 0.30f, 0.045f),
        "c_A" to floatArrayOf(1.04f, 0.54f, 0.045f),
        "c_X" to floatArrayOf(0.92f, 0.42f, 0.045f),
        "c_B" to floatArrayOf(1.16f, 0.42f, 0.045f)
    )

    // rectangles : id -> (gauche, haut, droite, bas)
    private val rects = mapOf(
        "a_lt" to floatArrayOf(0.28f, 0.02f, 0.54f, 0.10f),
        "a_rt" to floatArrayOf(0.86f, 0.02f, 1.12f, 0.10f),
        "c_LB" to floatArrayOf(0.28f, 0.12f, 0.56f, 0.19f),
        "c_RB" to floatArrayOf(0.84f, 0.12f, 1.12f, 0.19f),
        "a_up" to floatArrayOf(0.415f, 0.595f, 0.465f, 0.655f),
        "a_down" to floatArrayOf(0.415f, 0.705f, 0.465f, 0.765f),
        "a_left" to floatArrayOf(0.35f, 0.655f, 0.415f, 0.705f),
        "a_right" to floatArrayOf(0.465f, 0.655f, 0.53f, 0.705f)
    )

    private fun lit(id: String): Boolean = highlight == id || pressed.contains(id)

    override fun onDraw(c: Canvas) {
        val s = minOf(width / 1.4f, height.toFloat())
        val ox = (width - 1.4f * s) / 2f
        val oy = (height - s) / 2f

        line.strokeWidth = 0.012f * s + 1f
        line.color = body
        c.drawRoundRect(ox + 0.17f * s, oy + 0.20f * s, ox + 1.23f * s, oy + 0.92f * s, 0.22f * s, 0.22f * s, line)

        for ((id, r) in rects) {
            val on = lit(id)
            val l = ox + r[0] * s
            val t = oy + r[1] * s
            val rr = ox + r[2] * s
            val b = oy + r[3] * s
            if (on) {
                fill.color = green
                c.drawRoundRect(l, t, rr, b, 0.02f * s, 0.02f * s, fill)
            } else {
                line.color = dim
                c.drawRoundRect(l, t, rr, b, 0.02f * s, 0.02f * s, line)
            }
        }

        for ((id, r) in circles) {
            val cx = ox + r[0] * s
            val cy = oy + r[1] * s
            val rad = r[2] * s
            val stickClick = (id == "stickL" && lit("c_LS")) || (id == "stickR" && lit("c_RS"))
            val on = lit(id) || stickClick
            if (on) {
                fill.color = green
                c.drawCircle(cx, cy, rad, fill)
            } else {
                line.color = dim
                c.drawCircle(cx, cy, rad, line)
            }
            if (id == "stickL" || id == "stickR") {
                line.color = if (on) green else dim
                c.drawCircle(cx, cy, rad * 0.55f, line)
                val dot = if (id == "stickL") lDot else rDot
                if (dot != null) {
                    fill.color = green
                    c.drawCircle(cx + dot.first * rad * 0.8f, cy + dot.second * rad * 0.8f, rad * 0.22f, fill)
                }
            }
        }
    }
}
