package com.moussa.padmapper

import android.content.Context
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View

/** Mini fenêtre invisible (1 pixel) qui reçoit les axes de la manette : sticks, croix, gâchettes. */
class StickView(ctx: Context, private val svc: PadService) : View(ctx) {

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if ((event.source and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK ||
            event.actionMasked != MotionEvent.ACTION_MOVE
        ) {
            return super.onGenericMotionEvent(event)
        }
        svc.onMotion(event)
        return true
    }
}
