package com.moussa.padmapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * Moteur multi-touch : garde une liste de "doigts" virtuels (contacts) et envoie
 * toutes les 40 ms UN SEUL geste contenant tous les doigts, pour que
 * stick + boutons fonctionnent en même temps.
 */
class TouchEngine(
    private val svc: AccessibilityService,
    private val screenW: () -> Int,
    private val screenH: () -> Int
) {
    private class Contact(var cx: Float, var cy: Float) {
        var wx = cx
        var wy = cy
        var stroke: StrokeDescription? = null
        var lift = false
        var once = false
        var reset = false
        var ax = 0f
        var ay = 0f
        var holdMs = 0L      // appui chronométré (TAP long) ; 0 = pas chronométré
        var releaseAt = 0L   // instant où le doigt doit se lever
        var durMs = 0L       // durée du geste pour un appui bref (0 = dt)
        val script = ArrayList<Pair<Float, Float>>()
    }

    private val dt = 40L
    private val handler = Handler(Looper.getMainLooper())
    private val contacts = LinkedHashMap<String, Contact>()
    private var running = false
    private var counter = 0

    private fun clampX(v: Float) = v.coerceIn(0f, (screenW() - 1).toFloat())
    private fun clampY(v: Float) = v.coerceIn(0f, (screenH() - 1).toFloat())

    /** Pose un doigt qui reste appuyé jusqu'à up(). */
    fun down(id: String, x: Float, y: Float, reset: Boolean = false) {
        val old = contacts[id]
        if (old != null && !old.lift) return
        val c = Contact(clampX(x), clampY(y))
        c.reset = reset
        c.ax = c.cx
        c.ay = c.cy
        contacts[id] = c
        kick()
    }

    /** Déplace un doigt déjà posé. */
    fun moveTo(id: String, x: Float, y: Float) {
        val c = contacts[id] ?: return
        if (c.lift) return
        c.wx = x
        c.wy = y
        kick()
    }

    private fun isDirty(c: Contact): Boolean =
        c.reset || c.stroke == null || c.lift || c.once || c.script.isNotEmpty() || c.holdMs > 0 ||
                clampX(c.wx) != c.cx || clampY(c.wy) != c.cy

    fun up(id: String) {
        val c = contacts[id] ?: return
        c.lift = true
        kick()
    }

    fun upAll() {
        contacts.values.forEach { it.lift = true }
        kick()
    }

    /** Appui de [holdMs] ms (≤ 40 ms : appui bref ; plus long : le doigt reste posé jusqu'à l'heure). */
    fun tap(x: Float, y: Float, holdMs: Int = 40) {
        val c = Contact(clampX(x), clampY(y))
        if (holdMs <= dt) {
            c.once = true
            c.durMs = holdMs.toLong().coerceAtLeast(1L)
        } else {
            c.holdMs = holdMs.toLong()
        }
        contacts["t${counter++}"] = c
        kick()
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Int = 240) {
        val c = Contact(clampX(x1), clampY(y1))
        val steps = (durationMs / dt).toInt().coerceIn(1, 60)
        for (i in 1..steps) {
            c.script.add(Pair(x1 + (x2 - x1) * i / steps, y1 + (y2 - y1) * i / steps))
        }
        contacts["s${counter++}"] = c
        kick()
    }

    private fun kick() {
        if (running) return
        running = true
        cycle()
    }

    private fun cycle() {
        contacts.values.removeAll { it.reset && it.lift }
        if (contacts.isEmpty() || !contacts.values.any { isDirty(it) }) {
            running = false
            return
        }
        val builder = GestureDescription.Builder()
        val max = GestureDescription.getMaxStrokeCount()
        val ended = ArrayList<Pair<String, Contact>>()
        val fresh = ArrayList<String>()
        val now = SystemClock.uptimeMillis()
        var n = 0
        for ((id, c) in contacts) {
            if (n >= max) break
            if (c.holdMs > 0 && c.stroke != null && c.releaseAt != 0L && now >= c.releaseAt) c.lift = true
            if (c.reset) {
                // Mode compatibilité : chaque mise à jour est un geste complet
                // qui part près du centre et glisse jusqu'à la position du stick.
                val tx = clampX(c.wx)
                val ty = clampY(c.wy)
                val sx = c.ax + (tx - c.ax) * 0.35f
                val sy = c.ay + (ty - c.ay) * 0.35f
                val rp = Path()
                rp.moveTo(sx, sy)
                if (sx != tx || sy != ty) rp.lineTo(tx, ty)
                builder.addStroke(StrokeDescription(rp, 0, 60, false))
                c.stroke = null
                c.cx = tx
                c.cy = ty
                n++
                continue
            }
            var ex = c.wx
            var ey = c.wy
            val cont: Boolean
            if (c.script.isNotEmpty()) {
                val p = c.script.removeAt(0)
                ex = p.first
                ey = p.second
                cont = c.script.isNotEmpty()
            } else {
                cont = !(c.lift || c.once)
            }
            ex = clampX(ex)
            ey = clampY(ey)
            val path = Path()
            path.moveTo(c.cx, c.cy)
            if (ex != c.cx || ey != c.cy) path.lineTo(ex, ey)
            val prev = c.stroke
            val s = if (prev == null) {
                if (c.holdMs > 0) c.releaseAt = now + c.holdMs
                fresh.add(id)
                StrokeDescription(path, 0, if (c.once && c.durMs > 0) c.durMs else dt, cont)
            } else {
                prev.continueStroke(path, 0, dt, cont)
            }
            builder.addStroke(s)
            c.stroke = s
            c.cx = ex
            c.cy = ey
            n++
            if (!cont) ended.add(Pair(id, c))
        }
        if (n == 0) {
            running = false
            return
        }
        val ok = svc.dispatchGesture(
            builder.build(),
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    finish(ended, false)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    finish(ended, true)
                }
            },
            null
        )
        if (!ok) {
            // Android a refusé le geste : on retire seulement les doigts neufs (cause probable)
            // et on relance les autres, au lieu de tout effacer (stick compris).
            fresh.forEach { contacts.remove(it) }
            contacts.values.forEach { it.stroke = null }
            if (contacts.isEmpty()) running = false else handler.postDelayed({ cycle() }, dt)
        }
    }

    private fun finish(ended: List<Pair<String, Contact>>, cancelled: Boolean) {
        for ((id, c) in ended) {
            if (contacts[id] === c) contacts.remove(id)
        }
        if (cancelled) contacts.values.forEach { it.stroke = null }
        if (contacts.isEmpty()) {
            running = false
            return
        }
        if (cancelled) handler.postDelayed({ cycle() }, dt) else cycle()
    }
}
