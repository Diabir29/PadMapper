package com.moussa.padmapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import kotlin.math.abs

class PadService : AccessibilityService() {

    companion object {
        var instance: PadService? = null
    }

    private class Held(val stroke: StrokeDescription, val x: Float, val y: Float)

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var currentPkg = "global"
    private var ownForeground = false
    private var bindings: MutableList<Binding> = mutableListOf()
    private var bubble: TextView? = null
    private var editor: EditorOverlay? = null
    private val held = HashMap<String, Held>()
    private val turbo = HashMap<String, Runnable>()

    var mappingOn = true
        set(v) {
            field = v
            bubble?.text = if (v) "🎮" else "⏸"
        }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bindings = Store.load(this, currentPkg)
        showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = event.packageName?.toString() ?: return
        if (p == packageName) {
            ownForeground = true
            return
        }
        if (p == "com.android.systemui") return
        ownForeground = false
        if (p == currentPkg) return
        currentPkg = p
        releaseAll()
        bindings = Store.load(this, p)
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null || !Keys.isPad(event)) return false
        val id = Keys.id(event)
        val ed = editor
        if (ed != null) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                ed.onPadKey(id, Keys.name(event))
            }
            return true
        }
        if (!mappingOn || ownForeground) return false
        val b = bindings.firstOrNull { it.key == id } ?: return false
        when (event.action) {
            KeyEvent.ACTION_DOWN -> if (event.repeatCount == 0) press(b)
            KeyEvent.ACTION_UP -> release(b)
        }
        return true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        releaseAll()
        editor?.let { wm.removeView(it) }
        bubble?.let { wm.removeView(it) }
        editor = null
        bubble = null
        instance = null
        return super.onUnbind(intent)
    }

    // ---------- Actions ----------

    private fun press(b: Binding) {
        when (b.type) {
            ActionType.TAP -> tap(b.x, b.y, 40)
            ActionType.SWIPE -> swipe(b)
            ActionType.HOLD -> holdStart(b)
            ActionType.TURBO -> startTurbo(b)
        }
    }

    private fun release(b: Binding) {
        when (b.type) {
            ActionType.HOLD -> holdEnd(b.key)
            ActionType.TURBO -> stopTurbo(b.key)
            else -> {}
        }
    }

    @Suppress("DEPRECATION")
    private fun metrics(): DisplayMetrics {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return m
    }

    private fun point(x: Float, y: Float): Path {
        val m = metrics()
        val p = Path()
        p.moveTo(x * m.widthPixels, y * m.heightPixels)
        return p
    }

    private fun send(s: StrokeDescription) {
        val g = GestureDescription.Builder().addStroke(s).build()
        dispatchGesture(g, null, null)
    }

    private fun tap(x: Float, y: Float, dur: Long) {
        send(StrokeDescription(point(x, y), 0, dur))
    }

    private fun swipe(b: Binding) {
        val m = metrics()
        val p = Path()
        p.moveTo(b.x * m.widthPixels, b.y * m.heightPixels)
        p.lineTo(b.x2 * m.widthPixels, b.y2 * m.heightPixels)
        send(StrokeDescription(p, 0, 250))
    }

    private fun holdStart(b: Binding) {
        val s = StrokeDescription(point(b.x, b.y), 0, 100, true)
        held[b.key] = Held(s, b.x, b.y)
        send(s)
    }

    private fun holdEnd(key: String) {
        val h = held.remove(key) ?: return
        handler.postDelayed({
            send(h.stroke.continueStroke(point(h.x, h.y), 0, 50, false))
        }, 150)
    }

    private fun startTurbo(b: Binding) {
        stopTurbo(b.key)
        val r = object : Runnable {
            override fun run() {
                tap(b.x, b.y, 30)
                handler.postDelayed(this, 90)
            }
        }
        turbo[b.key] = r
        handler.post(r)
    }

    private fun stopTurbo(key: String) {
        turbo.remove(key)?.let { handler.removeCallbacks(it) }
    }

    private fun releaseAll() {
        turbo.keys.toList().forEach { stopTurbo(it) }
        held.keys.toList().forEach { holdEnd(it) }
    }

    // ---------- Bulle et éditeur ----------

    private fun showBubble() {
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)
        val density = resources.displayMetrics.density
        val tv = TextView(ctx)
        tv.text = "🎮"
        tv.textSize = 18f
        tv.gravity = Gravity.CENTER
        tv.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0x99000000.toInt())
        tv.background = bg

        val size = (44 * density).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = (120 * density).toInt()

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        var longDone = false
        val longRun = Runnable {
            longDone = true
            mappingOn = !mappingOn
        }

        tv.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x
                    sy = lp.y
                    tx = e.rawX
                    ty = e.rawY
                    moved = false
                    longDone = false
                    handler.postDelayed(longRun, 700)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) {
                        moved = true
                        handler.removeCallbacks(longRun)
                    }
                    if (moved) {
                        lp.x = sx + dx
                        lp.y = sy + dy
                        wm.updateViewLayout(view, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRun)
                    if (!moved && !longDone) openEditor()
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longRun)
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
    }

    fun openEditor() {
        if (editor != null) return
        releaseAll()
        val list = Store.load(this, currentPkg)
        val m = metrics()
        val lp = WindowManager.LayoutParams(
            m.widthPixels, m.heightPixels,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        val themed = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)
        val ed = EditorOverlay(themed, this, list)
        wm.addView(ed, lp)
        editor = ed
        bubble?.visibility = android.view.View.GONE
    }

    fun closeEditor(save: Boolean, list: List<Binding>) {
        editor?.let { wm.removeView(it) }
        editor = null
        if (save) {
            Store.save(this, currentPkg, list)
            bindings = list.toMutableList()
        }
        bubble?.visibility = android.view.View.VISIBLE
    }
}
