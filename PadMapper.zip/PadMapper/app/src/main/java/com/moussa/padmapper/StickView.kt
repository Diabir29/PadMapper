package com.moussa.padmapper

import android.content.Context
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max

/** Mini fenêtre invisible (1 pixel) qui reçoit les axes de la manette : sticks, croix, gâchettes. */
class StickView(ctx: Context, private val svc: PadService) : View(ctx) {

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if ((event.source and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK ||
            event.actionMasked != MotionEvent.ACTION_MOVE
        ) {
            return super.onGenericMotionEvent(event)
        }
        val z = event.getAxisValue(MotionEvent.AXIS_Z)
        val rx0 = event.getAxisValue(MotionEvent.AXIS_RX)
        val rz = event.getAxisValue(MotionEvent.AXIS_RZ)
        val ry0 = event.getAxisValue(MotionEvent.AXIS_RY)
        val rx = if (abs(z) >= abs(rx0)) z else rx0
        val ry = if (abs(rz) >= abs(ry0)) rz else ry0
        val lt = max(
            event.getAxisValue(MotionEvent.AXIS_LTRIGGER),
            event.getAxisValue(MotionEvent.AXIS_BRAKE)
        )
        val rt = max(
            event.getAxisValue(MotionEvent.AXIS_RTRIGGER),
            event.getAxisValue(MotionEvent.AXIS_GAS)
        )
        svc.onAxes(
            event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y),
            rx, ry,
            event.getAxisValue(MotionEvent.AXIS_HAT_X), event.getAxisValue(MotionEvent.AXIS_HAT_Y),
            lt, rt
        )
        return true
    }
}
