package com.moussa.padmapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper

/**
 * Moteur multi-touch : garde une liste de "doigts" virtuels (contacts) et envoie
 * toutes les 40 ms UN SEUL geste contenant tous les doigts, pour que
 * stick + boutons fonctionnent en même temps.
 */
class TouchEngine(
    private val svc: AccessibilityService,
    private val screenW: () -> Int,
    private val screenH: () -> Int
) {
    private class Contact(var cx: Float, var cy: Float) {
        var wx = cx
        var wy = cy
        var stroke: StrokeDescription? = null
        var lift = false
        var once = false
        val script = ArrayList<Pair<Float, Float>>()
    }

    private val dt = 40L
    private val handler = Handler(Looper.getMainLooper())
    private val contacts = LinkedHashMap<String, Contact>()
    private var running = false
    private var counter = 0

    private fun clampX(v: Float) = v.coerceIn(0f, (screenW() - 1).toFloat())
    private fun clampY(v: Float) = v.coerceIn(0f, (screenH() - 1).toFloat())

    /** Pose un doigt qui reste appuyé jusqu'à up(). */
    fun down(id: String, x: Float, y: Float) {
        val old = contacts[id]
        if (old != null && !old.lift) return
        contacts[id] = Contact(clampX(x), clampY(y))
        kick()
    }

    /** Déplace un doigt déjà posé. */
    fun moveTo(id: String, x: Float, y: Float) {
        val c = contacts[id] ?: return
        if (c.lift) return
        c.wx = x
        c.wy = y
    }

    fun up(id: String) {
        val c = contacts[id] ?: return
        c.lift = true
        kick()
    }

    fun upAll() {
        contacts.values.forEach { it.lift = true }
        kick()
    }

    fun tap(x: Float, y: Float) {
        val c = Contact(clampX(x), clampY(y))
        c.once = true
        contacts["t${counter++}"] = c
        kick()
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val c = Contact(clampX(x1), clampY(y1))
        val steps = 6
        for (i in 1..steps) {
            c.script.add(Pair(x1 + (x2 - x1) * i / steps, y1 + (y2 - y1) * i / steps))
        }
        contacts["s${counter++}"] = c
        kick()
    }

    private fun kick() {
        if (running) return
        running = true
        cycle()
    }

    private fun cycle() {
        if (contacts.isEmpty()) {
            running = false
            return
        }
        val builder = GestureDescription.Builder()
        val max = GestureDescription.getMaxStrokeCount()
        val ended = ArrayList<Pair<String, Contact>>()
        var n = 0
        for ((id, c) in contacts) {
            if (n >= max) break
            var ex = c.wx
            var ey = c.wy
            val cont: Boolean
            if (c.script.isNotEmpty()) {
                val p = c.script.removeAt(0)
                ex = p.first
                ey = p.second
                cont = c.script.isNotEmpty()
            } else {
                cont = !(c.lift || c.once)
            }
            ex = clampX(ex)
            ey = clampY(ey)
            val path = Path()
            path.moveTo(c.cx, c.cy)
            if (ex != c.cx || ey != c.cy) path.lineTo(ex, ey)
            val prev = c.stroke
            val s = if (prev == null) {
                StrokeDescription(path, 0, dt, cont)
            } else {
                prev.continueStroke(path, 0, dt, cont)
            }
            builder.addStroke(s)
            c.stroke = s
            c.cx = ex
            c.cy = ey
            n++
            if (!cont) ended.add(Pair(id, c))
        }
        val ok = svc.dispatchGesture(
            builder.build(),
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    finish(ended, false)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    finish(ended, true)
                }
            },
            null
        )
        if (!ok) {
            contacts.clear()
            running = false
        }
    }

    private fun finish(ended: List<Pair<String, Contact>>, cancelled: Boolean) {
        for ((id, c) in ended) {
            if (contacts[id] === c) contacts.remove(id)
        }
        if (cancelled) contacts.values.forEach { it.stroke = null }
        if (contacts.isEmpty()) {
            running = false
            return
        }
        if (cancelled) handler.postDelayed({ cycle() }, dt) else cycle()
    }
}
