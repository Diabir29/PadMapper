package com.moussa.padmapper

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var keyInfo: TextView
    private lateinit var axesInfo: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        fun label(s: String, size: Float): TextView {
            val t = TextView(this)
            t.text = s
            t.textSize = size
            t.setPadding(0, pad / 2, 0, pad / 2)
            return t
        }

        root.addView(label("PadMapper", 26f))

        status = label("", 16f)
        root.addView(status)

        val btn = Button(this)
        btn.text = "1. Activer le service d'accessibilité"
        btn.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        root.addView(btn)

        root.addView(
            label(
                "Dans la liste, ouvre PadMapper et active-le. Une bulle 🎮 apparaît alors à l'écran.\n\n" +
                        "2. Ouvre ton jeu, touche la bulle 🎮, puis appuie sur chaque bouton de ta manette : " +
                        "un rond apparaît. Glisse-le sur la touche du jeu. Choisis ensuite Tap, Maintenir, " +
                        "Swipe (2 ronds : début et fin) ou Turbo. Termine avec « Terminé ».\n\n" +
                        "3. Joue. Appui long sur la bulle 🎮 = pause / reprise du mapping. " +
                        "Chaque jeu a son propre profil.", 14f
            )
        )

        root.addView(label("Test de la manette", 18f))
        root.addView(label("Appuie sur les boutons et bouge les sticks ici.", 13f))
        keyInfo = label("Dernier bouton : —", 15f)
        axesInfo = label("Sticks : —", 15f)
        root.addView(keyInfo)
        root.addView(axesInfo)

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (PadService.instance != null)
            "✅ Service actif"
        else
            "❌ Service inactif"
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (Keys.isPad(event)) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                keyInfo.text = "Dernier bouton : ${Keys.name(event)} (code ${event.keyCode}, scan ${event.scanCode})"
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if ((event.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            event.action == MotionEvent.ACTION_MOVE
        ) {
            axesInfo.text = String.format(
                "Stick G : %.2f / %.2f\nStick D : %.2f / %.2f\nL2 : %.2f   R2 : %.2f",
                event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y),
                event.getAxisValue(MotionEvent.AXIS_Z), event.getAxisValue(MotionEvent.AXIS_RZ),
                event.getAxisValue(MotionEvent.AXIS_LTRIGGER), event.getAxisValue(MotionEvent.AXIS_RTRIGGER)
            )
            return true
        }
        return super.onGenericMotionEvent(event)
    }
}
