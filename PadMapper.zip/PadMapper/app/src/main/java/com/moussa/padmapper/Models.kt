package com.moussa.padmapper

import android.content.Context
import android.view.InputDevice
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

enum class ActionType(val label: String) {
    TAP("Tap"),
    HOLD("Maintenir"),
    SWIPE("Swipe"),
    TURBO("Turbo")
}

data class Binding(
    val key: String,
    var name: String,
    var type: ActionType = ActionType.TAP,
    var x: Float = 0.5f,
    var y: Float = 0.5f,
    var x2: Float = 0.6f,
    var y2: Float = 0.5f
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("key", key)
        put("name", name)
        put("type", type.name)
        put("x", x.toDouble())
        put("y", y.toDouble())
        put("x2", x2.toDouble())
        put("y2", y2.toDouble())
    }

    companion object {
        fun fromJson(o: JSONObject): Binding = Binding(
            o.getString("key"),
            o.getString("name"),
            ActionType.valueOf(o.getString("type")),
            o.getDouble("x").toFloat(),
            o.getDouble("y").toFloat(),
            o.getDouble("x2").toFloat(),
            o.getDouble("y2").toFloat()
        )
    }
}

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("padmapper", Context.MODE_PRIVATE)

    fun load(c: Context, pkg: String): MutableList<Binding> {
        val s = prefs(c).getString("profile_$pkg", null) ?: return mutableListOf()
        val list = mutableListOf<Binding>()
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) list.add(Binding.fromJson(arr.getJSONObject(i)))
        } catch (e: Exception) {
            list.clear()
        }
        return list
    }

    fun save(c: Context, pkg: String, list: List<Binding>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(c).edit().putString("profile_$pkg", arr.toString()).apply()
    }
}

object Keys {
    fun id(e: KeyEvent): String =
        if (e.keyCode != KeyEvent.KEYCODE_UNKNOWN) "k${e.keyCode}" else "s${e.scanCode}"

    fun name(e: KeyEvent): String =
        if (e.keyCode != KeyEvent.KEYCODE_UNKNOWN)
            KeyEvent.keyCodeToString(e.keyCode).removePrefix("KEYCODE_")
        else "SCAN${e.scanCode}"

    fun isPad(e: KeyEvent): Boolean {
        val s = e.source
        return (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
                (s and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD ||
                KeyEvent.isGamepadButton(e.keyCode)
    }
}
