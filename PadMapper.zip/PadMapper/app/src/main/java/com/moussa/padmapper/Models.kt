package com.moussa.padmapper

import android.content.Context
import android.view.InputDevice
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

enum class ActionType(val label: String) {
    TAP("Tap"),
    HOLD("Maintenir"),
    SWIPE("Swipe"),
    TURBO("Turbo"),
    STICK("Stick")
}

data class Binding(
    val key: String,
    var name: String,
    var type: ActionType = ActionType.TAP,
    var x: Float = 0.5f,
    var y: Float = 0.5f,
    var x2: Float = 0.6f,
    var y2: Float = 0.5f
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("key", key)
        put("name", name)
        put("type", type.name)
        put("x", x.toDouble())
        put("y", y.toDouble())
        put("x2", x2.toDouble())
        put("y2", y2.toDouble())
    }

    companion object {
        fun fromJson(o: JSONObject): Binding = Binding(
            o.getString("key"),
            o.getString("name"),
            ActionType.valueOf(o.getString("type")),
            o.getDouble("x").toFloat(),
            o.getDouble("y").toFloat(),
            o.getDouble("x2").toFloat(),
            o.getDouble("y2").toFloat()
        )
    }
}

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("padmapper", Context.MODE_PRIVATE)

    fun load(c: Context, pkg: String): MutableList<Binding> {
        val s = prefs(c).getString("profile_$pkg", null) ?: return mutableListOf()
        val list = mutableListOf<Binding>()
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) list.add(Binding.fromJson(arr.getJSONObject(i)))
        } catch (e: Exception) {
            list.clear()
        }
        return list
    }

    fun axisMode(c: Context): Boolean = prefs(c).getBoolean("axis_mode", true)

    fun stickCompat(c: Context): Boolean = prefs(c).getBoolean("stick_compat", true)

    fun setStickCompat(c: Context, v: Boolean) {
        prefs(c).edit().putBoolean("stick_compat", v).apply()
    }

    fun setAxisMode(c: Context, v: Boolean) {
        prefs(c).edit().putBoolean("axis_mode", v).apply()
    }

    fun save(c: Context, pkg: String, list: List<Binding>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(c).edit().putString("profile_$pkg", arr.toString()).apply()
    }
}

object Keys {
    fun id(e: KeyEvent): String = when (e.keyCode) {
        KeyEvent.KEYCODE_DPAD_UP -> "a_up"
        KeyEvent.KEYCODE_DPAD_DOWN -> "a_down"
        KeyEvent.KEYCODE_DPAD_LEFT -> "a_left"
        KeyEvent.KEYCODE_DPAD_RIGHT -> "a_right"
        KeyEvent.KEYCODE_BUTTON_L2 -> "a_lt"
        KeyEvent.KEYCODE_BUTTON_R2 -> "a_rt"
        KeyEvent.KEYCODE_UNKNOWN -> "s${e.scanCode}"
        else -> "k${e.keyCode}"
    }

    fun name(e: KeyEvent): String = when (e.keyCode) {
        KeyEvent.KEYCODE_DPAD_UP -> "Croix ↑"
        KeyEvent.KEYCODE_DPAD_DOWN -> "Croix ↓"
        KeyEvent.KEYCODE_DPAD_LEFT -> "Croix ←"
        KeyEvent.KEYCODE_DPAD_RIGHT -> "Croix →"
        KeyEvent.KEYCODE_BUTTON_L2 -> "L2"
        KeyEvent.KEYCODE_BUTTON_R2 -> "R2"
        KeyEvent.KEYCODE_UNKNOWN -> "SCAN${e.scanCode}"
        else -> KeyEvent.keyCodeToString(e.keyCode).removePrefix("KEYCODE_")
    }

    fun isPad(e: KeyEvent): Boolean {
        val s = e.source
        return (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
                (s and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD ||
                KeyEvent.isGamepadButton(e.keyCode)
    }
}
