package com.moussa.padmapper

import android.accessibilityservice.GestureDescription
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var keyInfo: TextView
    private lateinit var axesInfo: TextView
    private lateinit var touchLog: TouchLogView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Keys.calib == null) Keys.calib = Store.loadCalib(this)
        val density = resources.displayMetrics.density
        val pad = (16 * density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        fun label(s: String, size: Float): TextView {
            val t = TextView(this)
            t.text = s
            t.textSize = size
            t.setPadding(0, pad / 2, 0, pad / 2)
            return t
        }

        root.addView(label("PadMapper", 26f))

        status = label("", 16f)
        root.addView(status)

        val btn = Button(this)
        btn.text = "1. Activer le service d'accessibilité"
        btn.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        root.addView(btn)

        root.addView(
            label(
                "Dans la liste, ouvre PadMapper et active-le. Une bulle 🎮 apparaît alors à l'écran.\n\n" +
                        "2. Étalonne ta manette (bouton ci-dessous), comme dans Octopus.\n\n" +
                        "3. Ouvre ton jeu, touche la bulle 🎮, puis appuie sur chaque bouton de ta manette : " +
                        "un rond apparaît. Glisse-le sur la touche du jeu. Choisis ensuite Tap, Maintenir, " +
                        "Swipe (2 ronds : début et fin) ou Turbo. Termine avec « Terminé ».\n\n" +
                        "4. Joue. Appui long sur la bulle 🎮 = pause / reprise du mapping. " +
                        "Chaque jeu a son propre profil.\n\n" +
                        "Sticks : touche ＋ Stick G / ＋ Stick D dans l'éditeur, place le rond violet sur le " +
                        "joystick virtuel du jeu et règle la taille avec le rond jaune.", 14f
            )
        )

        val calBtn = Button(this)
        calBtn.text = "Étalonner la manette"
        calBtn.setOnClickListener { startActivity(Intent(this, CalibrationActivity::class.java)) }
        root.addView(calBtn)

        root.addView(label("Style par défaut du stick analogique (modifiable pour chaque stick dans l'éditeur)", 16f))
        val rg = RadioGroup(this)
        val rbHold = RadioButton(this)
        rbHold.id = View.generateViewId()
        rbHold.text = "Maintenir (Hold) : le doigt reste posé et glisse"
        val rbRep = RadioButton(this)
        rbRep.id = View.generateViewId()
        rbRep.text = "Répéter (Repeat) : le geste est refait en boucle"
        rg.addView(rbHold)
        rg.addView(rbRep)
        if (Store.stickStyle(this) == 1) rbRep.isChecked = true else rbHold.isChecked = true
        rg.setOnCheckedChangeListener { _, checkedId ->
            Store.setStickStyle(this, if (checkedId == rbRep.id) 1 else 0)
        }
        root.addView(rg)

        val cb = CheckBox(this)
        cb.text = "Activer sticks analogiques, croix et gâchettes (peut mettre certains jeux en pause)"
        cb.isChecked = Store.axisMode(this)
        cb.setOnCheckedChangeListener { _, v -> Store.setAxisMode(this, v) }
        root.addView(cb)

        root.addView(label("Test du doigt virtuel", 18f))
        root.addView(
            label(
                "Touche un bouton : un doigt virtuel tourne 3 secondes dans la zone noire " +
                        "(le service doit être actif). Les compteurs montrent ce que l'écran reçoit.", 13f
            )
        )
        touchLog = TouchLogView(this)
        root.addView(
            touchLog,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (220 * density).toInt())
        )
        val testHold = Button(this)
        testHold.text = "Tester Maintenir"
        testHold.setOnClickListener { runTest(false) }
        root.addView(testHold)
        val testRep = Button(this)
        testRep.text = "Tester Répéter"
        testRep.setOnClickListener { runTest(true) }
        root.addView(testRep)

        root.addView(label("Test de la manette", 18f))
        root.addView(label("Appuie sur les boutons et bouge les sticks ici.", 13f))
        keyInfo = label("Dernier bouton : —", 15f)
        axesInfo = label("Sticks : —", 15f)
        root.addView(keyInfo)
        root.addView(axesInfo)

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    private fun runTest(repeat: Boolean) {
        val s = PadService.instance
        if (s == null) {
            status.text = "❌ Service inactif : active-le d'abord"
            return
        }
        touchLog.reset()
        val loc = IntArray(2)
        touchLog.getLocationOnScreen(loc)
        val cx = loc[0] + touchLog.width / 2f
        val cy = loc[1] + touchLog.height / 2f
        val r = minOf(touchLog.width, touchLog.height) / 3f
        s.selfTest(cx, cy, r, repeat)
    }

    override fun onResume() {
        super.onResume()
        status.text = (if (PadService.instance != null) "✅ Service actif" else "❌ Service inactif") +
                "\nDoigts virtuels max : " + GestureDescription.getMaxStrokeCount()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (Keys.isPad(event)) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                keyInfo.text = "Dernier bouton : ${Keys.name(event)} (code ${event.keyCode}, scan ${event.scanCode})"
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if ((event.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            event.action == MotionEvent.ACTION_MOVE
        ) {
            axesInfo.text = String.format(
                "Stick G : %.2f / %.2f\nStick D (Z/RZ) : %.2f / %.2f\nStick D (RX/RY) : %.2f / %.2f\nCroix : %.0f / %.0f\nL2 : %.2f   R2 : %.2f",
                event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y),
                event.getAxisValue(MotionEvent.AXIS_Z), event.getAxisValue(MotionEvent.AXIS_RZ),
                event.getAxisValue(MotionEvent.AXIS_RX), event.getAxisValue(MotionEvent.AXIS_RY),
                event.getAxisValue(MotionEvent.AXIS_HAT_X), event.getAxisValue(MotionEvent.AXIS_HAT_Y),
                event.getAxisValue(MotionEvent.AXIS_LTRIGGER), event.getAxisValue(MotionEvent.AXIS_RTRIGGER)
            )
            return true
        }
        return super.onGenericMotionEvent(event)
    }
}

/** Zone noire qui compte les touches reçues (poser, bouger, relever le doigt). */
class TouchLogView(ctx: Context) : View(ctx) {
    private var downs = 0
    private var moves = 0
    private var ups = 0
    private var cancels = 0
    private var lx = -1f
    private var ly = -1f
    private val density = resources.displayMetrics.density
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f * resources.displayMetrics.density
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2BFFAA.toInt() }

    init {
        setBackgroundColor(Color.BLACK)
    }

    fun reset() {
        downs = 0
        moves = 0
        ups = 0
        cancels = 0
        lx = -1f
        ly = -1f
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> downs++
            MotionEvent.ACTION_MOVE -> moves++
            MotionEvent.ACTION_UP -> ups++
            MotionEvent.ACTION_CANCEL -> cancels++
        }
        lx = event.x
        ly = event.y
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        if (lx >= 0f) c.drawCircle(lx, ly, 14f * density, dot)
        val h = text.textSize * 1.4f
        c.drawText("Doigts posés : $downs", 12f * density, h, text)
        c.drawText("Mouvements : $moves", 12f * density, h * 2, text)
        c.drawText("Doigts relevés : $ups", 12f * density, h * 3, text)
        c.drawText("Annulations : $cancels", 12f * density, h * 4, text)
    }
}
